import React from 'react';
import { Link } from 'react-router-dom';
import { ShoppingCart, Store, User2 } from 'lucide-react';
import { useStore } from '../store/useStore';

export function Navbar() {
  const { cart, user } = useStore();
  
  return (
    <nav className="bg-white shadow-lg">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex justify-between items-center h-16">
          <Link to="/" className="flex items-center space-x-2">
            <Store className="h-8 w-8 text-indigo-600" />
            <span className="font-bold text-xl">ModernShop</span>
          </Link>
          
          <div className="flex items-center space-x-4">
            <Link to="/cart" className="relative">
              <ShoppingCart className="h-6 w-6 text-gray-600 hover:text-indigo-600" />
              {cart.length > 0 && (
                <span className="absolute -top-2 -right-2 bg-indigo-600 text-white rounded-full w-5 h-5 flex items-center justify-center text-xs">
                  {cart.length}
                </span>
              )}
            </Link>
            
            <Link to={user?.isAdmin ? "/admin" : "/login"}>
              <User2 className="h-6 w-6 text-gray-600 hover:text-indigo-600" />
            </Link>
          </div>
        </div>
      </div>
    </nav>
  );
}