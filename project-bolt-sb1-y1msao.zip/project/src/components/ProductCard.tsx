import React, { useState } from 'react';
import { useStore } from '../store/useStore';
import { Product } from '../types';
import { ShoppingCart, Plus, Minus } from 'lucide-react';
import { ImageSlider } from './ImageSlider';

interface ProductCardProps {
  product: Product;
}

export function ProductCard({ product }: ProductCardProps) {
  const { addToCart } = useStore();
  const [showDetails, setShowDetails] = useState(false);

  // Simulate multiple product images
  const productImages = [
    product.image,
    'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=800',
    'https://images.unsplash.com/photo-1546868871-7041f2a55e12?w=800'
  ];

  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden transition-transform hover:scale-105">
      <div
        className="cursor-pointer"
        onClick={() => setShowDetails(!showDetails)}
      >
        {showDetails ? (
          <ImageSlider images={productImages} autoPlayInterval={4000} />
        ) : (
          <img
            src={product.image}
            alt={product.name}
            className="w-full h-48 object-cover"
          />
        )}
      </div>
      <div className="p-4">
        <h3 className="text-lg font-semibold text-gray-800">{product.name}</h3>
        <p className="text-sm text-gray-600 mt-1">{product.description}</p>
        <div className="mt-4 flex items-center justify-between">
          <span className="text-xl font-bold text-indigo-600">
            ${product.price.toFixed(2)}
          </span>
          <button
            onClick={() => addToCart(product)}
            className="flex items-center space-x-1 bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700 transition-colors"
          >
            <ShoppingCart className="h-5 w-5" />
            <span>Add to Cart</span>
          </button>
        </div>
      </div>
    </div>
  );
}