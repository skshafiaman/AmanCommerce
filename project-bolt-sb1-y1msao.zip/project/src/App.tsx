import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Navbar } from './components/Navbar';
import { Home } from './pages/Home';
import { Admin } from './pages/Admin';
import { Cart } from './pages/Cart';
import { useStore } from './store/useStore';

// Temporary login simulation
const simulateLogin = () => {
  const store = useStore.getState();
  store.setUser({ isAdmin: true });
};

// Simulate some initial products
const initializeProducts = () => {
  const store = useStore.getState();
  const products = [
    {
      id: '1',
      name: 'Premium Wireless Headphones',
      description: 'High-quality wireless headphones with noise cancellation',
      price: 199.99,
      image: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=800',
      category: 'Electronics',
      stock: 10
    },
    {
      id: '2',
      name: 'Smart Watch Pro',
      description: 'Advanced smartwatch with health tracking features',
      price: 299.99,
      image: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=800',
      category: 'Electronics',
      stock: 15
    },
    {
      id: '3',
      name: 'Premium Backpack',
      description: 'Durable and stylish backpack for everyday use',
      price: 79.99,
      image: 'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=800',
      category: 'Accessories',
      stock: 20
    }
  ];
  
  products.forEach(product => store.addProduct(product));
};

// Initialize the store
simulateLogin();
initializeProducts();

function App() {
  return (
    <Router>
      <div className="min-h-screen bg-gray-50">
        <Navbar />
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/admin" element={<Admin />} />
          <Route path="/cart" element={<Cart />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;